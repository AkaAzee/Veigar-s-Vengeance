from cx_Freeze import setup, Executable

setup(name="Veigar's Vengeance",
      version="1.0",
      description="",
      executables=[Executable("main.py")])
