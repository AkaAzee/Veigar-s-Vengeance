print(480/1920)
print(272/1080)

print(1080*0.25)