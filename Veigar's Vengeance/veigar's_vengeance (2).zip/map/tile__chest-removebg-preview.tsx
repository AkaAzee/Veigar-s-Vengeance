<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="tile__chest-removebg-preview" tilewidth="16" tileheight="16" tilecount="96" columns="12">
 <image source="C:/Users/Megaport/Downloads/tile__chest-removebg-preview.png" width="192" height="128"/>
</tileset>
