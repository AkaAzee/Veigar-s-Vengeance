<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="ashlands_tileset" tilewidth="16" tileheight="16" tilecount="840" columns="40">
 <image source="ashlands_tileset.png" width="640" height="336"/>
</tileset>
